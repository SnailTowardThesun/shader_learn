/*
 <samplecode>
    <abstract>
        Main application entry point.
    </abstract>
 <samplecode>
*/

@import Cocoa;

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
