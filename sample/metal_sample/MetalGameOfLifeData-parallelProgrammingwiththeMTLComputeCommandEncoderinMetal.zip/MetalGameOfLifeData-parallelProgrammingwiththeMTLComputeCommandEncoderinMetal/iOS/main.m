/*
 <samplecode>
    <abstract>
        Main application entry point.
    </abstract>
 <samplecode>
*/

#import <UIKit/UIKit.h>
#import "AAPLAppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AAPLAppDelegate class]));
    }
}
