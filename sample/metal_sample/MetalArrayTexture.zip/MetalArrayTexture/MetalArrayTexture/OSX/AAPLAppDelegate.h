//
//  AppDelegate.h
//  MetalTexturedQuad-OSX
//
//  Created by Dan Omachi on 10/16/15.
//  Copyright © 2015 Apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AAPLAppDelegate : NSObject <NSApplicationDelegate>


@end

