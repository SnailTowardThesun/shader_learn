//
//  main.m
//  MetalTexturedQuad-OSX
//
//  Created by Dan Omachi on 10/16/15.
//  Copyright © 2015 Apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
