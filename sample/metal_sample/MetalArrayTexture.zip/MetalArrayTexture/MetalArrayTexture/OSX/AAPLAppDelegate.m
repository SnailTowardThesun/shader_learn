//
//  AppDelegate.m
//  MetalTexturedQuad-OSX
//
//  Created by Dan Omachi on 10/16/15.
//  Copyright © 2015 Apple. All rights reserved.
//

#import "AAPLAppDelegate.h"

@interface AAPLAppDelegate ()

@end

@implementation AAPLAppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

@end
