# MetalTexturedQuad

This sample shows how to create a basic textured quad in metal. It includes all transformations needed to ensure correct rendering orientation of the textured quad.

## Requirements

### Build

iOS 9 SDK

### Runtime

iOS 9, 64 bit devices

Copyright (C) 2015 Apple Inc. All rights reserved.

